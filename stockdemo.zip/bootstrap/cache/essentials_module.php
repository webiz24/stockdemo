<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Essentials\\Providers\\EssentialsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Essentials\\Providers\\EssentialsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);